/*
Instructions on how to generate the Repopulate [NewPost...] tables script
=========================================================================

1) If the [Import...] tables are not empty, TRUNCATE them with the following script:
*/
USE INLDB
GO

TRUNCATE TABLE [migration].[ImportTrainingEventVertical];
TRUNCATE TABLE [migration].[ImportTrainingEventHorizontal];
TRUNCATE TABLE [migration].[ImportLocations];
TRUNCATE TABLE [migration].[ImportParticipants];
TRUNCATE TABLE [migration].[ImportInstructors];
GO
/*
2) Use the Import Data... task to import the data from the XLSX file into the [Import...] tables.

    a) Right-click database ("INLDB") & select the "Tasks >" and "Import Data..." menu options.

    b) Data Source
        Microsoft Excel
        File Path: C:\Data_Load_Files\Manual Build of Colombia TE Data\TEST DATA LOAD FILE.xlsx
        Excel Version: 2007-2010
        First row has column name = YES (checked)

    c) Destination
        SQL Server Native Client 11.0
        Server: SURF
        Windows Authentication
        Database: INLDB

    d) Copy data from one or more tables or views

    e) Select Tables and Views
        Source: ImportTrainingEventHorizontal$  Destination: migration.ImportTrainingEventHorizontal
            Review Data Type Mapping
                Should not require any changes

        Source: ImportLocations$                Destination: migration.ImportLocations
            Review Data Type Mapping
                Should not require any changes

        Source: ImportPArticipants$             Destination: migration.ImportPArticipants
            Edit Mappings button:
                Reassign the mappings of the DateTime values to the XXXXXX-OUT columns:
                    SOURCE                      DESTINATION
                    ======                      ===========
                    NewPostImportID             ImportID
                    DOB                         <Ignore>
                    DOB-OUT                     DOB
                    LocalGovTrustCertDate       <Ignore>
                    LocalGovTrustCertDate-OUT   LocalGovTrustCertDate
                    ExternalVettingDate         <Ignore>
                    ExternalVettingDate-OUT     ExternalVettingDate
                    PassportExpirationDate      <Ignore>
                    PassportExpirationDate-OUT  PassportExpirationDate
                    
        Source: ImportInstructors$              Destination: migration.ImportInstructors
            Edit Mappings button:
                Reassign the mappings of the DateTime values to the XXXXXX-OUT columns:
                    SOURCE                      DESTINATION
                    ======                      ===========
                    NewPostImportID             ImportID
                    DOB                         <Ignore>
                    DOB-OUT                     DOB
                    LocalGovTrustCertDate       <Ignore>
                    LocalGovTrustCertDate-OUT   LocalGovTrustCertDate
                    ExternalVettingDate         <Ignore>
                    ExternalVettingDate-OUT     ExternalVettingDate
                    PassportExpirationDate      <Ignore>
                    PassportExpirationDate-OUT  PassportExpirationDate
                
    f) Review Data Type Mapping
        Make sure to check the Convert column for the ImportID field.
    
    g) Run the process and verify that the data was in fact imported.

3)  Load the [NewPostImportLog] table with the list of files that are being imported.
    Use the following script and adjust as needed.
*/
USE INLDB
GO

-- Empty out the table.
DELETE 
  FROM [migration].[NewPostImportLog];

-- List contents of [NewPostImportLog] table.
SELECT [NewPostImportID]
      ,[CountryName]
      ,[CountryID]
      ,[PostName]
      ,[PostID]
      ,[FileName]
      ,[HasTrainingEvent]
      ,[TrainingEventSubmittedCount]
      ,[HasLocations]
      ,[LocationsSubmittedCount]
      ,[HasParticipants]
      ,[ParticipantsSubmittedCount]
      ,[HasInstructors]
	  ,[InstructorsSubmittedCount] 
      ,[ModifiedByAppUserID]
      ,[ModifiedDate]
  FROM [migration].[NewPostImportLog];

-- Create the [NewPostImportLog] records.
INSERT INTO [migration].[NewPostImportLog]
    ([ImportSessionID]
    ,[FileName]
    ,[CountryName]
    ,[CountryID]
    ,[PostName]
    ,[PostID]
    ,[HasTrainingEvent]
    ,[TrainingEventSubmittedCount]
    ,[HasLocations]
    ,[LocationsSubmittedCount]
    ,[HasParticipants]
    ,[ParticipantsSubmittedCount]
    ,[HasInstructors]
    ,[InstructorsSubmittedCount]    
    ,[NewPostImportDateStamp]
    ,[ModifiedByAppUserID])
VALUES
    (1, 'Test Data for Testing Training Event Import Process.xlsx', 'Colombia', 2053, 'Bogota', 1038, 1, 1, 1, 3, 1, 5, 1, 2, getutcdate(), 2);

-- List contents of [NewPostImportLog] table.
SELECT [NewPostImportID]
      ,[CountryName]
      ,[CountryID]
      ,[PostName]
      ,[PostID]
      ,[FileName]
      ,[HasTrainingEvent]
      ,[TrainingEventSubmittedCount]
      ,[HasLocations]
      ,[LocationsSubmittedCount]
      ,[HasParticipants]
      ,[ParticipantsSubmittedCount]
      ,[HasInstructors]
	  ,[InstructorsSubmittedCount] 
      ,[ModifiedByAppUserID]
      ,[ModifiedDate]
  FROM [migration].[NewPostImportLog];

SELECT 'Sum of [NewPostImportLog] records' AS ListingName,
	   SUM([TrainingEventSubmittedCount]) AS SumTrainingEvents,
       SUM([LocationsSubmittedCount]) AS SumLocations,
       SUM([ParticipantsSubmittedCount]) AS SumParticipantsSubmitted,
	   SUM([InstructorsSubmittedCount]) AS SumInstructorsSubmitted
  FROM [migration].[NewPostImportLog];

SELECT 'Count of [NewPost...] table records' AS ListingName,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostTrainingEvents
       ) AS TrainingEventsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostLocations
       ) AS LocationsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostParticipants
       ) AS ParticipantsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostInstructors
       ) AS InstructorsCnt;
/*
4)  Run the following script to clean up and move the data from the [Import...] tables
    to the [NewPost...] tables.
*/
USE INLDB
GO

-- Get rid of all [Import...] rows that has ALL NULL columns.
EXECUTE [migration].[DeleteAllNULLRecordsFromImportTables];

-- Update [NewPostImportLog] table with [Import...] row counts.
EXECUTE [migration].[GetImportTableCounts]
        @NewPostImportID = @NewPostImportIDValue;

-- Upload the data from the [Import...] tables to the [NewPost...] tables.
EXECUTE [migration].[CreateNewPostTrainingEventRecord]
        @NewPostImportID = @NewPostImportIDValue;

EXECUTE [migration].[CreateNewPostLocationsRecords]
        @NewPostImportID = @NewPostImportIDValue;

EXECUTE [migration].[CreateNewPostParticipantsRecords]
        @NewPostImportID = @NewPostImportIDValue;

EXECUTE [migration].[CreateNewPostInstructorsRecords]
        @NewPostImportID = @NewPostImportIDValue;

-- List out all records in the [NewPost...] tables.
SELECT *
  FROM [migration].[NewPostTrainingEvents];

SELECT *
  FROM [migration].[NewPostLocations];

SELECT *
  FROM [migration].[NewPostParticipants];

SELECT *
  FROM [migration].[NewPostInstructors];
/*
5) Export the data in the [Import...] tables to a set of temporary tables in a temporary
   or scratch database.

    a) Right-click database ("INLDB") & select the "Tasks >" and "Export Data..." menu options.

    b) Data Source
        SQL Server Native Client 11.0
        Server: SURF
        Windows Authentication
        Database: INLDB

    c) Destination
        SQL Server Native Client 11.0
        Server: SURF
        Windows Authentication
        Database: DEV_TEST

    d) Copy data from one or more tables or views

    e) Select Tables and Views
            SOURCE (INLDB)          DESTINATION (DEV_TEST)
            ==============          ======================
            NewPostTrainingEvents   migration.NewPostTrainingEvents
            NewPostLocations        migration.NewPostLocations
            NewPostParticipants     migration.NewPostParticipants              
            NewPostInstructors      migration.NewPostInstructors

    f) Verify mappings for each source & destination using the Edit Mappings... button.

    g) Run the process and verify that the data was in fact exported correctly.

6) Clean up & prepare the exported tables for the scripting process by removing the
   Primary Key, SysStartTime, & SysEndTime columns from the exported tables.

7) Generate a data script from the exported tables.
    a) Right-click the database name ("DEV_TEST") & select the "Tasks >" and 
       "Generate Scripts..." menu options.

    b) Select the 4 NewPost... tables listed under table objects:
        migration.NewPostTrainingEvents
        migration.NewPostLocations
        migration.NewPostParticipants
        migration.NewPostInstructors

    c) Click the "Advanced" button and locate the "Types of data to script" setting 
       which is located at the end of the General section.  Change the drop-down 
       selection to "Data only".

    d) Select the "Save to file" option, specifying a path & file name to save the 
       script to.    

    e) Click "Next" and "Finish" to generate the script file.

8) You will need to edit the script file that was just created.

    a) Open the script file that was just generated in an editor and reorder the INSERT
       statements according to the below target tables listing:
            NewPostTrainingEvents
            NewPostLocations
            NewPostParticipants
            NewPostInstructors
       
    b) Change the USE statement to reference the INLDB database.

    c) Insert the following code blocks as indicated
*/
-- Purge [NewPost...] tables of any data.
DELETE 
  FROM [migration].[NewPostImportLog];
DELETE 
  FROM [migration].[NewPostTrainingEvents];
DELETE 
  FROM [migration].[NewPostLocations];
DELETE 
  FROM [migration].[NewPostParticipants];
DELETE 
  FROM [migration].[NewPostParticipants];
DELETE 
  FROM [migration].[NewPostInstructors];

-- Generate BEFORE counts.
SELECT 'BEFORE: Count of [NewPost...] table records' AS ListingName,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostImportLog
       ) AS ImportLogCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostTrainingEvents
       ) AS TrainingEventsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostLocations
       ) AS LocationsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostParticipants
       ) AS ParticipantsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostInstructors
       ) AS InstructorsCnt;

-- Create the [NewPostImportLog] records.
    -- Copy the  "Create the [NewPostImportLog] records" INSERT statement block from step #3 to here.

-- Repopulate the [NewPostTrainingEvents] table.
    -- Put NewPostTrainingEvents INSERTS here.

-- Repopulate the [NewPostLocations] table.
    -- Put NewPostLocations INSERTS here.

-- Repopulate the [NewPostParticipants] table.
    -- Put NewPostParticipants INSERTS here.

-- Repopulate the [NewPostInstructors] table.
    -- Put NewPostInstructors INSERTS here.

-- List contents of [NewPostImportLog] table.
SELECT [NewPostImportID]
      ,[CountryName]
      ,[CountryID]
      ,[PostName]
      ,[PostID]
      ,[FileName]
      ,[HasTrainingEvent]
      ,[TrainingEventSubmittedCount]
      ,[HasLocations]
      ,[LocationsSubmittedCount]
      ,[HasParticipants]
      ,[ParticipantsSubmittedCount]
      ,[HasInstructors]
	  ,[InstructorsSubmittedCount] 
      ,[ModifiedByAppUserID]
      ,[ModifiedDate]
  FROM [migration].[NewPostImportLog];

-- Generate BEFORE counts.
SELECT 'AFTER: Sum of [NewPostImportLog] records' AS ListingName,
	   SUM([TrainingEventSubmittedCount]) AS SumTrainingEvents,
       SUM([LocationsSubmittedCount]) AS SumLocations,
       SUM([ParticipantsSubmittedCount]) AS SumParticipantsSubmitted,
	   SUM([InstructorsSubmittedCount]) AS SumInstructorsSubmitted
  FROM [migration].[NewPostImportLog];

SELECT 'AFTER: Count of [NewPost...] table records' AS ListingName,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostTrainingEvents
       ) AS TrainingEventsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostLocations
       ) AS LocationsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostParticipants
       ) AS ParticipantsCnt,
	   (
        SELECT COUNT(*)
	    FROM migration.NewPostInstructors
       ) AS InstructorsCnt;
/*
9) At this point the Training Event Data Load script is now ready for use if you need to 
   regenerate the Training Event template data to be loaded.
*/