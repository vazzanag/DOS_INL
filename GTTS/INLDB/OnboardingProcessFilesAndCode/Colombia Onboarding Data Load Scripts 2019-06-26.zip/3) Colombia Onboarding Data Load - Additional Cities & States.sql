/*
    NAME:   Colombia Onboarding Data Load - Additional Cities & States
    
    DESCR:  Load additional cities & states needed by Colombia for importing Training
            Event template files.          
*/

-- Point to INLDB Database.
USE INLDB
GO

SET NOCOUNT ON;

-- **********************************************
-- Define new City & State values to be imported.
-- *********************************************
DECLARE @AppUserID AS INT = 2;          -- AppUser = ONBOARDING 

-- Declare a table variable to hold the additional states being added.  
DECLARE @CityStateCountryTbl AS TABLE
(
    [CityName] NVARCHAR(100),
    [CityID] INT,
    [StateName] NVARCHAR(75),
    [StateID] INT,
    [CountryName] NVARCHAR(75), 
    [CountryID] INT
);        

-- Insert State, Country values into the table variable.
INSERT INTO @CityStateCountryTbl 
    ([CityName], [StateName], [CountryName], [CountryID])
VALUES
    ('Santo Domingo', 'National District', 'Dominican Republic', 2069),
    ('Quito', 'Pichincha', 'Ecuador', 2070),
    ('Santa Tecla', 'La Libertad',  'El Salvador', 2072),
    ('Tegucigalpa', 'Francisco Morazán',  'Honduras', 2107),
    ('Dothan', 'Alabama',  'United States', 2254),
    ('Miami', 'Florida', 'United States', 2254),
    ('Columbus', 'Georgia', 'United States', 2254),                                                            
    ('Stennis Space Center', 'Mississippi', 'United States', 2254),
    ('San Antonio', 'Texas', 'United States', 2254),
    ('Newport News', 'Virginia', 'United States', 2254)

-- *************************************************
-- Import Additional States into the [States] table.
-- *************************************************
PRINT 'BEGIN Additional States Import.';
DBCC CHECKIDENT ('[location].[States]');

-- Insert new states into the [States] table.
INSERT INTO [location].[States]
        ([StateName], [CountryID], [IsActive], [ModifiedByAppUserID])
SELECT ol.StateName, CountryID, 1, @AppUserID
	FROM @CityStateCountryTbl ol
WHERE ol.StateName NOT IN
		(SELECT s.StateName
			FROM [location].[States] s
			WHERE s.CountryID = ol.CountryID);

-- Update the table variable with State IDs from the newly added States in the States table.
UPDATE tbl
   SET tbl.StateID = s.StateID
  FROM @CityStateCountryTbl tbl
INNER JOIN [location].[States] s ON s.CountryID = tbl.CountryID AND s.StateName = tbl.StateName;

-- Insert Unknown States into the [States] table for those Countries that don't have one.
INSERT INTO [location].[States]
            ([StateName], [StateCodeA2], [Abbreviation], [CountryID], [IsActive], [ModifiedByAppUserID])
SELECT 'Unknown', 'UK' , 'UNK', f.CountryID, 1, @AppUserID
	FROM (SELECT DISTINCT ol.CountryID
			FROM @CityStateCountryTbl ol
			WHERE ol.CountryID NOT IN
				(SELECT c.CountryID
					FROM [location].[Countries] c
					JOIN [location].[States] s ON s.CountryID = c.CountryID
					WHERE s.StateName = 'Unknown')) f;

DBCC CHECKIDENT ('[location].[States]');
PRINT 'END Additional States Import.';
PRINT '';

-- *************************************************
-- Import Additional Cities into the [Cities] table.
-- *************************************************
PRINT 'BEGIN Additional Cities Import.';
DBCC CHECKIDENT ('[location].[Cities]');

-- Insert new cities into the [Cities] table.
INSERT INTO [location].[Cities]
        ([CityName], [StateID], [IsActive], [ModifiedByAppUserID]) 
SELECT ol.CityName, s.StateID, 1, @AppUserID
  FROM @CityStateCountryTbl ol
  JOIN [location].[States] s ON s.StateName = ol.StateName
 WHERE ol.CityName NOT IN 
		 (SELECT c.CityName
			FROM [location].[Cities] c
			JOIN [location].[States] s ON c.StateID = s.StateID
             AND ol.CountryID = s.CountryID);

-- Insert Unknown Cities into the [Cities] table for those States  that don't have one.
INSERT INTO [location].[Cities]
        ([CityName], [StateID], [IsActive], [ModifiedByAppUserID]) 
SELECT 'Unknown', s2.StateID, 1, @AppUserID
  FROM (SELECT DISTINCT s.StateID
	      FROM [location].[States] s
		  JOIN @CityStateCountryTbl ol ON ol.StateName = s.StateName) s2
 WHERE s2.StateID NOT IN 
		(SELECT s.StateID
		   FROM [location].[Cities] c
		   JOIN [location].[States] s ON s.StateID = c.StateID
		  WHERE c.CityName = 'Unknown');

DBCC CHECKIDENT ('[location].[Cities]');
PRINT 'END Additional Cities Import.';
PRINT '';

SET NOCOUNT OFF;